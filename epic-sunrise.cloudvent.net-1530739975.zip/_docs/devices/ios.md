---
title: iOS
category: Devices
order: 1
---

Use ChatApp on most of your Apple devices. Only the latest versions are supported.

To install ChatApp on your device:

1. Open the App Store
2. Search for ChatApp
3. Select **Install**

![](//placehold.it/800x600)
