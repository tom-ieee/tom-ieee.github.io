---
title: General fixes and improvements
type: minor
---

This release fixes a few minor issues reported by users. We've also made a few quality of life improvements.

**Features:**

* Streamlined access to contact details
* Better sort order for archived messages

**Fixes:**

* Input sometimes getting stuck
* One more memory leak obliterated
